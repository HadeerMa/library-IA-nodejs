const router =require("express").Router();
const db =require("../routes/db-config");
const authorized = require("../middleware/authorize");
//const admin = require("../middleware/admin");
const { body, validationResult } = require("express-validator");
const util = require("util"); // helper
const fs = require("fs"); // file system
//const { request } = require("http");
//const { strictEqual } = require("assert");
const mysql = require('mysql');



//search book
router.get("", async (req, res) => {
  const query = util.promisify(db.query).bind(db);
  let search = "";
  if (req.query.search) {
    // QUERY PARAMS
    search = `where name LIKE '%${req.query.search}%' or description LIKE '%${req.query.search}%' or author LIKE '%${req.query.search}%' or field LIKE '%${req.query.search}%' or publicationdate LIKE '%${req.query.search}%' `;
  }
  const books = await query(`select * from books ${search}`);
  
  res.status(200).json(books);
});



//view
router.get("/view/:id", async (req, res) => {
  const query = util.promisify(db.query).bind(db);
  const book = await query("select * from books where id = ?", [
    req.params.id,
  ]);
  if (!book[0]) {
    res.status(404).json({ ms: "book not found !" });
  }
   
  res.status(200).json(book[0]);
});


// send a request to get a specific book

// router.post('/book-request', async(req, res) => {
//   try {
//   const request_book={ book_id:req.body ,book_name:req.body } 
//   const query = util.promisify(db.query).bind(db);
//   await query("insert into request set ? ",request_book );
//  // const values = [ name,book_id];

  
//     res.status(200).json({
//       msg: "book chapter created successfully !",
//   });

//    // res.send('Book request sent successfully!');
  
// }
//  catch (err) {
//   console.log(err);
// res.status(500).json(err);
// }
// });


router.post('/request', (req, res) => {
  const { book_name, book_id ,user_id} = req.body;

  // Insert book request into MySQL database
  const sql = 'INSERT INTO request (book_name, book_id, user_id ) VALUES (?, ?,?)';
  const values = [book_name, book_id, user_id ];

  db.query(sql,values, (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error submitting book request');
    } else {
      console.log(`Inserted book request with ID ${result.insertrequestId}`);
      res.send('Book request submitted successfully!');
    }
  });
});

// router.post('/request', (req, res) => {
//   const {  book_name } = req.body.book_name;
//   const {  book_id } = req.body.book_id;
//   //const status = 'pending'; // Set status to 'pending' by default

//   // Insert book request into MySQL database
//   const sql = 'INSERT INTO request ( book_name,book_id ) VALUES ( ?)';
//   db.query(sql, [ book_name], (err, result) => {
//     if (err) 
//     throw err;
//     console.log(`Inserted book request with ID ${result.insertbook_id}`);
//     res.send('Book request submitted successfully!');
//   });
// });



// Route handler for search history
router.get('', (req, res) => {
  const { user_id } = req.query;

  // Retrieve search history from book_search_history table
  const sql = 'SELECT * FROM book_search_history WHERE user_id = ?';
  db.query(sql, [user_id], (err, results) => {
    if (err) throw err;
    console.log(`Found ${results.length} book searches for user ${user_id}`);

    // Send search history to client
    res.status(200).json(results);
  });
});



// // Route to filter books by title and author
// router.get('/books', (req, res) => {
//   const { name, author } = req.query;

//   let sql = 'SELECT * FROM books WHERE 1 = 1';
//   let params = [];

//   if (name) {
//     sql += ' AND name LIKE ?';
//     params.push(`%${name}%`);
//   }

//   if (author) {
//     sql += ' AND author LIKE ?';
//     params.push(`%${author}%`);
//   }

//   connection.query(sql, params, (err, results) => {
//     if (err) 
//     throw err;
//     console.log(`Retrieved ${results.length} books with name containing '${name}' and author containing '${author}'`);
//     res.json(results);
//   });
// });



module.exports= router;