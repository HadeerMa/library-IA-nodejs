const router = require("express").Router();
const db =require("../routes/db-config");
const { body, validationResult } = require("express-validator");
const util = require("util"); // helper
const bcrypt = require("bcrypt");
const crypto= require("crypto");

// Registration
router.post('/signup',body("email").isEmail().withMessage("Please Enter a valid Email"),
                     // body("name").isString().withMessage("Please Enter a valid Name").isLength({min : 10, max:20}).withMessage("Please Should be between 10:20 Character"),
                      body("password"),
                      body("phone").isDecimal(),
                      async(req, res) => {
    try{
       // validation Request
       const errors = validationResult(req);
       if(!errors.isEmpty()){
        return res.status(400).json({errors:errors.array()});

       }
       // check Is Email Exist  [await,async]
       const query = util.promisify (db.query).bind(db);// transform query mySql --> promise to use [await/async]
       const checkEmailExists = await query("select * from user where email = ?",[req.body.email]);
       if(checkEmailExists.length>0){
        res.status(400).json({
            errors:[
                {
                    msg:"Email Already Exists! "
                },
            ],
        });
       }
       // 3- PREPARE OBJECT USER TO -> SAVE
       const userData = {
        email: req.body.email,
        password: await bcrypt.hash(req.body.password, 10),
        phone : req.body.phone
       // token: crypto.randomBytes(16).toString("hex"), // JSON WEB TOKEN,package CRYPTO -> RANDOM ENCRYPTION STANDARD
      }; 
      await query("insert into user set ? ", userData);
        delete userData.password;
        res.status(200).json(userData);
    }
    catch{  
        res.status(500).json({err:err});
    }
  }
);

// LOGIN
router.post(
  "/login",
  body("email").isEmail().withMessage("please enter a valid email!"),
  body("password"),
    
  async (req, res) => {
    try {
      // 1- VALIDATION REQUEST [manual, express validation]
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }
      // 2- CHECK IF EMAIL EXISTS
      const query = util.promisify(db.query).bind(db); // transform query mysql --> promise to use [await/async]
      const user = await query("select * from user where email = ?", [
        req.body.email,
      ]);
      if (user.length == 0) {
        res.status(404).json({
          errors: [
            {
              msg: "email or password not found !",
            },
          ],
        });
      }

      // 3- COMPARE HASHED PASSWORD
      const checkPassword = await bcrypt.compare(
        req.body.password,
        user[0].password
      );
      if (checkPassword) {
        delete user[0].password;
        res.status(200).json(user[0]);
      } else {
        res.status(404).json({
          errors: [
            {
              msg: "email or password not found !",
            },
          ],
        });
      }
    } catch (err) {
      res.status(500).json({ err: err });
    }
  }
);
module.exports =router;


// const express =require("express");
// //const register =require("./register");
// const login =require("./login");
// const logout =require("./logout");

// const router =express.Router();

// // khlas msh m7tagahm 3mlt path f index
//  //router.post('/register',register);
//  router.post('/login',login);

 
// router.get('/logout',logout);



