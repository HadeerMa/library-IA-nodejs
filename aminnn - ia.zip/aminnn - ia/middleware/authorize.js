const db =require("../routes/db-config");
const util =require("util"); //helper


const authorized = async(req,res,next)=>{
    const query = util.promisify(db.query).bind(db);
    const {token}= req.headers;
const user= await query("SELECT * FROM user WHERE token =?",[token]);
if(user[0]){
    next();
} else {
    res.status(403).json({
        msg: "u r not admin"
    });
}
}
module.exports= authorized;