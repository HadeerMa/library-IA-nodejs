const express =require("express");
const db =require("../routes/db-config");
const router =express.Router();
const admin = require("../middleware/admin");

// Create a new reader
router.post('/',admin, (req, res) => {
  const { phone, email ,password } = req.body;
  const sql = 'INSERT INTO user (phone, email,password) VALUES (?, ?,?)';
  db.query(sql, [phone, email,password], (err, result) => {
    if (err) {
      throw err;
    }
    res.send('Reader created successfully');
  });
});
  
  // Get all readers
  router.get('/',admin, (req, res) => {
    const sql = 'SELECT * FROM user';
    db.query(sql, (err, result) => {
      if (err) {
        throw err;
      }
      res.send(result);
    });
  });
  
  // Get a single reader
  router.get('/',admin, (req, res) => {
    const { id } = req.params;
    const sql = 'SELECT * FROM user WHERE id = ?';
    db.query(sql, id, (err, result) => {
      if (err) {
        throw err;
      }
      res.send(result[0]);
    });
  });
  
  // Update a reader
  router.put('/', admin, (req, res) => {
    const { id } = req.params;
    const { phone, email,password } = req.body;
    const sql = 'UPDATE user SET phone = ?, email = ?,password = ? WHERE id = ?';
    db.query(sql, [phone, email, id,password], (err, result) => {
      if (err) {
        throw err;
      }
      res.send('Reader updated successfully');
    });
  });
  
  // Delete a reader
  router.delete('/:id',admin, (req, res) => {
    const { id } = req.params;
    const sql = 'DELETE FROM user WHERE id = ?';
    db.query(sql, id, (err, result) => {
      if (err) {
        throw err;
      }
      res.send('Reader deleted successfully');
    });
  });
  module.exports=router;