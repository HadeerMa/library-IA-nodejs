const express =require("express");
const db =require("../routes/db-config");
const router =express.Router();
const admin = require("../middleware/admin");


//Accept request
router.post('/acceptRequest/:requestId', (req, res) => {
  const requestId = req.body.user_id;
 // const book_id = req.body.book_id;
 // const  requestId= req.body.requestId;
 const sql = `UPDATE request SET status = 'accepted' WHERE requestId = ?`;
 db.query(sql, [requestId], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error submitting book request');
    }
    else{
      console.log(`Inserted book request with ID ${result.insertrequestId}`);
       res.send('Request accepted');
  }
   
  });
});

// Decline request 
router.post('/declineRequest/:requestId', (req, res) => {
  const requestId = req.body.user_id;
  const sql = `UPDATE request SET status = 'declined' WHERE requestId = ?`;
  db.query(sql, [requestId], (err, result) => {
    if (err) throw err;
    res.send('Request declined');
  });
});


module.exports=router; 