const express =require("express");
const mysql = require("mysql");
const { v4 } = require('uuid');
const router =express.Router();
const db =require("../routes/db-config");
const authorized = require("../middleware/authorize");
const admin = require("../middleware/admin");
const fs = require("fs"); // file system
const util = require("util");
const upload=require("../middleware/uploadfile");
const { body, validationResult } = require("express-validator");
const books =[  ]
const book_chapters=[];


const multer = require('multer');
const knex = require('knex');

//const db = knex({ });
// const STATUS_OK = 200;
// const STATUS_BAD_REQUEST = 400;

// class BookService {
//   constructor(db) {
//     this.db = db;
//   }

//   // async createBook(book) {
//   //   await 
//   //   this.
//   //   db.insert(book).into('books');
//   // } 
  
//   async createBook(book) {
//   const query = util.promisify(db.query).bind(db);
//         await query("insert into books set ? ", book);
        
//       }
// }

// class BookValidator {
//   validate(req) {
//     return validationResult(req);
//   }
// }

// // class BookUploader {
// //   constructor() {
// //     this.upload = multer({ dest: 'uploads/' });
// //   }

// //   uploadFile(req, res, next) {
// //     this.upload.single("pdffile")(req, res, next);
// //   }
// // }

// const bookValidator = new BookValidator();
// //const bookUploader = new BookUploader(); 
// const bookService = new BookService(db);

// router.post('/', admin,
//  // bookUploader.uploadFile,
//   body("name").isString(),
//     body("description")
//     .isString()
//  ,
//  body("author")
//  .isString()
// ,
// body("field")
// .isString()
// ,
// body("publicationdate")
// .isDecimal()
// , 
//   // other validations...
//   async (req, res) => {
//     try {
//       const errors = bookValidator.validate(req);
//       if (!errors.isEmpty()) {
//         return res.status(STATUS_BAD_REQUEST).json({ errors: errors.array() });
//       }

//       // if (!req.file) {
//       //   return res.status(STATUS_BAD_REQUEST).json({
//       //     errors: [{ msg: "pdf file is Required" }] 
//       //   });
//       // }

//       const book = { 
//         name: req.body.name, 
//         description: req.body.description,  
//         author: req.body.author,  
//         field: req.body.field,  
//         publicationdate: req.body.publicationdate,  
//        // pdfFile: req.file.filename 
//       };

//       await bookService.createBook(book);
//       res.status(STATUS_OK).json({ msg: "Book created successfully!" });
//     } catch (err) {
//       console.log(err);
//       res.status(500).json({ err: "Internal server error" });
//     }
//   }
// );

router.get('/', async (req, res)=> {
    const query = util.promisify(db.query).bind(db);
      const books = await query("select * from books ");
        res.status(200).json(books);
    });
  


  // post request: create book.
  router.post('/', admin,
  upload.single("pdffile"),
  body("name")
    .isString()
  ,

  body("description")
    .isString()
 ,
 body("author")
 .isString()
,

body("field")
.isString()
,
body("publicationdate")
.isDecimal()
,

  async (req, res) => {
    try {
      // 1- VALIDATION REQUEST [manual, express validation]
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

     // 2- VALIDATE THE IMAGE
      if (!req.file) {
        return res.status(400).json({
          errors: [
            {
              msg: "pdf file is Required",
            },
          ],
        });
    }

    const books = {
    
        name: req.body.name,
        description: req.body.description,
        author : req.body.author,
        field : req.body.field,
        publicationdate : req.body.publicationdate,
        pdffile: req.file.filename,
      };

         // 4 - insert book
      const query = util.promisify(db.query).bind(db);
      await query("insert into books set ? ", books);
      res.status(200).json({
        msg: "book created successfully !",
      });

    } catch (err) {
        console.log(err);
      res.status(500).json(err);
    }
  })

        // put request: updata book.
router.put('/:id'
,admin,
    
    upload.single("pdffile"),
    body("name")
      .isString()
    ,
  
    body("description")
      .isString()
   ,
   body("author")
   .isString()
  ,
  

  body("field")
  .isString()
  ,
  body("publicationdate")
  .isDecimal()
  ,
  
  async (req, res) => {
      try {
        // 1- VALIDATION REQUEST [manual, express validation]
        const query = util.promisify(db.query).bind(db);
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
          return res.status(400).json({ errors: errors.array() });
        }
  
            // 4 - check the book
          
          const books=  await query("select * from books where id= ? ",  [
                req.params.id,
              ]);
              if (!books[0]) {
                res.status(404).json({ msg: "book not found !" });
                
            };
  
      const booksobject = {
          name: req.body.name,
          description: req.body.description,
          author : req.body.author,
          field : req.body.field,
          publicationdate : req.body.publicationdate,
          pdffile: req.file.filename,
        };
  
        if (req.file) {
            booksobject.pdffile = req.file.filename;
            // delete old file
            fs.unlinkSync("./upload/" + books[0].pdffile); 
          }
    
          // 4- update book
          await query("update books set ? where id = ?", [booksobject, books[0].id]);
    
          res.status(200).json({
            msg: "movie updated successfully",
          });
       
    
      } catch (err) {
          console.log(err);
        res.status(500).json(err);
      }
});


//delete request : delete movie
router.delete('/:id',admin, 
  async (req, res) => {
    try {
      // 1- CHECK IF MOVIE EXISTS OR NOT
      const query = util.promisify(db.query).bind(db);
      const books = await query("select * from books where id = ?", [
        req.params.id,
      ]);
      if (!books[0]) {
        res.status(404).json({ msg: "book not found !" });
      }

     // 2- delete file
      fs.unlinkSync("./upload/" + books[0].pdffile); 

      await query("delete from books where id = ?", [books[0].id]);
      res.status(200).json({
        msg: "book delete successfully",
      });
    } catch (err) {
      res.status(500).json(err);
    }
  });



  //book_chapters
// view books chapters
router.get('/chapters',admin,
async (req, res)=> {
    const query = util.promisify(db.query).bind(db);
      const books = await query("select * from books_chapters ");
        res.status(200).json(books);
    });


// create book chapter
    router.post('/chapters', admin,

  body("title")
    .isString()
  ,

  body("description")
    .isString()
 ,
 body("books_id").isNumeric(),

async (req, res) => {
    try {
      // 1- VALIDATION REQUEST [manual, express validation]
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }
      
      const query = util.promisify(db.query).bind(db);
      const books= await query("select * from books where id = ?", [
        req.body.books_id,
      ]);
      if (!books[0]) {
        res.status(404).json({ ms: "book not found !" });
      }

      const book_chapters = {
        books_id: books[0].id,
       title: req.body.title,
        description: req.body.description,}

     
        await query("insert into books_chapters set ? ", book_chapters);
        res.status(200).json({
          msg: "book chapter created successfully !",
        });
  
      } catch (err) {
          console.log(err);
        res.status(500).json(err);
      }
    });


     // put request: updata book chapter.
router.put('/chapters/:id'
,admin,
    body("title")
      .isString()
    ,
  
    body("description")
      .isString()
   ,
   body("books_id").isNumeric(),
   async (req, res) => {
    try {
      // 1- VALIDATION REQUEST [manual, express validation]
     // const query = util.promisify(db.query).bind(db);
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const query = util.promisify(db.query).bind(db);
      const books= await query("select * from books where id = ?", [
        req.body.books_id,
      ]);
      if (!books[0]) {
        res.status(404).json({ ms: "book not found !" });
      }

          // 4 - check the book chapter
        
        const book_chapters=  await query("select * from books_chapters where id= ? ",  [
              req.params.id,
            ]);
            if (!book_chapters[0]) {
              res.status(404).json({ msg: "book chapter not found !" });
              
          };

          const up_book_chapters = {
            books_id: books[0].id,
            title: req.body.title,
             description: req.body.description,}

              // 4- update book
          await query("update books_chapters set ? where id = ?", [up_book_chapters, book_chapters[0].id]);
    
          res.status(200).json({
            msg: "book chapter updated successfully",
          });
       
    
      } catch (err) {
          console.log(err);
        res.status(500).json(err);
      }
});
  
//delete request : delete book chapter
router.delete('/chapters/:id',admin, 
  async (req, res) => {
    try {
      
      const query = util.promisify(db.query).bind(db);
    
      const book_chapters = await query("select * from books_chapters where id = ?", [
        req.params.id,
      ]);
      if (!book_chapters[0]) {
        res.status(404).json({ msg: "book not found !" });
      }
    
    
      await query("delete from books_chapters where id = ?", [book_chapters[0].id]);
      res.status(200).json({
        msg: "book chapter deleteted successfully",
      });
    
    } catch (err) {
      res.status(500).json(err);
    }
  });

module.exports=router; 