const express =require("express");
const db =require("../routes/db-config");
const router =express.Router();
const admin = require("../middleware/admin");



// Get request history for all books 
router.get('/', (req, res) => {
  const sql = `SELECT * FROM request r 
              JOIN books b ON r.book_id = b.id 
              ORDER BY r.create_at DESC`;
  db.query(sql, (err, results) => {
    if (err) throw err;
    res.send(results);
  });
});
module.exports=router; 

