const express =require("express");
const bodyParser = require('body-parser');
//const db =require("./routes/db-config");
const cookie =require("cookie-parser");
const app= express();
const books =require('./crud/books');
const acc_req =require('./crud/acc_req');
const managereader =require('./crud/managereader');
const history =require('./crud/history');
//const reader =require('./controllers/reader');
//const book_chapters =require('./crud/book_chapters');
app.use(bodyParser.urlencoded({ extended: false }));
// parse application/json
app.use(bodyParser.json());
app.use('/books',books);
app.use('/acc_req',acc_req);
app.use('/managereader',managereader);
app.use('/history',history);
//app.use('/reader',reader);
//app.use('/book_chapters',book_chapters);
//const path =require("path");
//const PORT = process.env.PORT || 3000;
//const HOST = process.env.HOST ||  "localhost";
//app.use('/js',express.static(__dirname +"/public/js"));
//app.use('/css',express.static(__dirname +"/public/css"));
//app.set('view engine','ejs');
//app.set('views','./views');
app.use(cookie());


//const publicDirectory =path.join(__dirname,'./public');
//app.use(express.static(publicDirectory));
// parse json url encoded bodies (as sent by html forms)
// app.use(express.json());
// db.connect((err)=>{
//     if(err) throw err;
//     console.log("sql connected");
// });
//define routes
//app.use('/',require('./routes/pages'));
const auth = require("./controllers/auth");
app.use("/auth", auth);

const reader = require("./controllers/reader");
app.use("/reader", reader);
//app.use('/api',require('./controllers/auth'));
//app.use(bodyParser.urlencoded({ extended: false }));
// app.use((req,res,next)=>{
//     res.status(404).send('page not found')
// });
//app.listen(PORT,HOST,(res)=>{
//    console.log(`server is running on ${PORT}:${HOST}`);
//});
app.listen(3001,()=>{
 console.log("server is running");
})
